#!/bin/bash
gcc -Wall main.c functions.c -std=c99 -o tp2 
## Algunos codigos a tener en cuenta: 139(Segmentation fault), 255(Archivo inexistente)
######TEST 1###########
#if [ "$?" != 255 ] && [ ! -s stderr.txt ]; then ## Si stderr esta vacio la salida no fue dirigida correctamente, si el codigo es 255 no existe el file
./tp2 test1.txt > stdout.txt
DIFF=$(diff expected_result1.txt stdout.txt) 
if [ "$DIFF" != "" ]; then
   echo "Test lectura en cache de un valor almacenado: ERROR";
else
   echo "Test lectura en cache de un valor almacenado: OK";
fi
###FIN TEST 1##########




######TEST 2###########
./tp2 test2.txt > stdout.txt
DIFF=$(diff expected_result2.txt stdout.txt) 
if [ "$DIFF" != "" ]; then
   echo "Test miss en un write: ERROR";
else
   echo "Test miss en un write: OK";
fi
###FIN TEST 2##########


####TEST 3#######
./tp2 test3.txt > stdout.txt
DIFF=$(diff expected_result3.txt stdout.txt) 
if [ "$DIFF" != "" ]; then
   echo "Test write en cache con un hit: ERROR";
else
   echo "Test write en cache con un hit: OK";
fi

####FIN TEST 3###




####TEST 4#######
./tp2 test4.txt > stdout.txt 
if [ "$?" != 253 ]; then
   echo "Test lectura fuera del rango de direcciones da error: ERROR";
else
   echo "Test lectura fuera del rango de direcciones da error: OK";
fi
####FIN TEST 4###

####TEST 5#######
./tp2 test5.txt > stdout.txt 
if [ "$?" != 253 ]; then
   echo "Test escritura fuera del rango de direcciones da error: ERROR";
else
   echo "Test escritura fuera del rango de direcciones da error: OK";
fi
####FIN TEST 5###


####TEST 6#######
./tp2 prueba1.mem > stdout.txt
DIFF=$(diff expected_result6.txt stdout.txt)  
if [ "$DIFF" != "" ]; then
   echo "Test prueba1.mem: ERROR";
else
   echo "Test prueba1.mem: OK";
fi
####FIN TEST 6###




####TEST 7#######
./tp2 prueba2.mem > stdout.txt 
DIFF=$(diff expected_result7.txt stdout.txt) 
if [ "$DIFF" != "" ]; then 
   echo "Test prueba2.mem: ERROR";
else
   echo "Test prueba2.mem: OK";
fi
####FIN TEST 7###


####TEST 8#######
./tp2 prueba3.mem > stdout.txt
DIFF=$(diff expected_result8.txt stdout.txt)  
if [ "$DIFF" != "" ]; then 
   echo "Test prueba3.mem: ERROR";
else
   echo "Test prueba3.mem: OK";
fi
####FIN TEST 8###


####TEST 9#######
./tp2 prueba4.mem > stdout.txt 
DIFF=$(diff expected_result9.txt stdout.txt) 
if [ "$DIFF" != "" ]; then 
   echo "Test prueba4.mem: ERROR";
else
   echo "Test prueba4.mem: OK";
fi
####FIN TEST 9###


####TEST 10#######
./tp2 prueba5.mem > stdout.txt 
DIFF=$(diff expected_result10.txt stdout.txt) 
if [ "$DIFF" != "" ]; then 
   echo "Test prueba5.mem: ERROR";
else
   echo "Test prueba5.mem: OK";
fi
####FIN TEST 10###





