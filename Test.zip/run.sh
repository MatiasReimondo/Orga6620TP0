#!/bin/bash
gcc -Wall functions.c main.c -std=c99 -o tp0 
## Algunos codigos a tener en cuenta: 139(Segmentation fault) , 251(
######TEST 1###########
./tp0 -i wrongfile.txt > dest_test1.txt
if [ "$?" != 255 ]; then ##Pregunto por la salida del programa, el codigo 255 implica que el archivo que se intento abrir no existe
   echo "Test archivo inexistente: ERROR";
else
   echo "Test archivo inexistente: OK";
fi
###FIN TEST 1##########

######TEST 2###########
./tp0 -w -c -l < input_test_2.txt > dest_test2.txt #Redirecciono el contenido de input_test_2.txt a la entrada standard
DIFF=$(diff dest_test_2.txt expected_result_test_2.txt) 
if [ "$DIFF" != "" ]; then
    echo "Test stdin corto: ERROR";
else
    echo "Test stdin corto: OK";
fi
###FIN TEST 2##########


######TEST 3###########
./tp0 -h  > dest_test_3.txt
DIFF=$(diff dest_test_3.txt expected_result_test_3.txt) 
if [ "$DIFF" != "" ]; then
   echo "Test opcion --help y -h: ERROR";
else
   ./tp0 -help  > dest_test_3.txt #Corro el mismo comando pero con el otro formato de help
   DIFF=$(diff dest_test_3.txt expected_result_test_3.txt)
   if [ "$DIFF" != "" ]; then
         echo "Test opcion -help y -h: ERROR";
   else
         echo "Test opcion -help y -h : OK";
   fi
fi
###FIN TEST 3##########



######TEST 4###########
./tp0 -V  > dest_test_4.txt
DIFF=$(diff dest_test_4.txt expected_result_test_4.txt) 
if [ "$DIFF" != "" ]; then
   echo "Test opcion -version y -V: ERROR";
else
   ./tp0 -Version  > dest_test_4.txt #Corro el mismo comando pero con el otro formato de version
   DIFF=$(diff dest_test_4.txt expected_result_test_4.txt)
   if [ "$DIFF" != "" ]; then
         echo "Test opcion -version y -V: ERROR";
   else
         echo "Test opcion -version y -V : OK";
   fi
fi
###FIN TEST 4##########





######TEST 5###########
./tp0 -c -w -l -i input_test_5.txt  > dest_test_5.txt
DIFF=$(diff dest_test_5.txt expected_result_test_5.txt) 
if [ "$DIFF" != "" ]; then
    echo "Test archivo con un solo caracter: ERROR";
else
    echo "Test archivo con un solo caracter: OK";
fi
###FIN TEST 5##########


######TEST 6###########
./tp0 -c -w -l -i input_test_6.txt  > dest_test_6.txt
DIFF=$(diff dest_test_6.txt expected_result_test_6.txt) 
if [ "$DIFF" != "" ]; then
    echo "Test archivo con delimitadores distintos: ERROR";
else
    echo "Test archivo con delimitadores distintos: OK";
fi
###FIN TEST 6##########


######TEST 7###########
./tp0 -c -w -l -i input_test_7.txt  > dest_test_7.txt
DIFF=$(diff dest_test_7.txt expected_result_test_7.txt) 
if [ "$DIFF" != "" ]; then
    echo "Test archivo corto: ERROR";
else
    echo "Test archivo corto: OK";
fi
###FIN TEST 7##########


######TEST 8###########
./tp0 -c -w -l -i input_test_8.txt  > dest_test_8.txt
DIFF=$(diff dest_test_8.txt expected_result_test_8.txt) 
if [ "$DIFF" != "" ]; then
    echo "Test archivo vacio: ERROR";
else
    echo "Test archivo vacio: OK";
fi
###FIN TEST 8##########


######TEST 9###########
./tp0 -c -w -l -i input_test_9.txt  > dest_test_9.txt
DIFF=$(diff dest_test_9.txt expected_result_test_9.txt) 
if [ "$DIFF" != "" ]; then
    echo "Test archivo mediano: ERROR";
else
    echo "Test archivo mediano: OK";
fi
###FIN TEST 9##########


######TEST 10###########
./tp0 -c -w -l -i alice.txt  > dest_test_10.txt
DIFF=$(diff dest_test_10.txt expected_result_test_10.txt) 
if [ "$DIFF" != "" ]; then
    echo "Test alice: ERROR";
else
    echo "Test alice: OK";
fi
###FIN TEST 10##########


######TEST 11###########
./tp0 -c -w -l -i beowulf.txt  > dest_test_11.txt
DIFF=$(diff dest_test_11.txt expected_result_test_11.txt) 
if [ "$DIFF" != "" ]; then
    echo "Test beowulf: ERROR";
else
    echo "Test beowulf: OK";
fi
###FIN TEST 11##########


######TEST 12###########
./tp0 -c -w -l -i cyclopedia.txt  > dest_test_12.txt
DIFF=$(diff dest_test_12.txt expected_result_test_12.txt) 
if [ "$DIFF" != "" ]; then
    echo "Test archivo cyclopedia: ERROR";
else
    echo "Test archivo cyclopedia: OK";
fi
###FIN TEST 12##########


######TEST 13###########
./tp0 -c -w -l -i elquijote.txt  > dest_test_13.txt
DIFF=$(diff dest_test_13.txt expected_result_test_13.txt) 
if [ "$DIFF" != "" ]; then
    echo "Test El Quijote: ERROR";
else
    echo "Test El Quijote: OK";
fi
###FIN TEST 13##########


######TEST 14###########
./tp0 -c -w -l < elquijote.txt  > dest_test_14.txt #Cargo todo el quijote por stdin con '<'
DIFF=$(diff dest_test_14.txt expected_result_test_14.txt) 
if [ "$DIFF" != "" ]; then
    echo "Test stdin largo: ERROR";
else
    echo "Test stdin largo: OK";
fi
###FIN TEST 14##########






