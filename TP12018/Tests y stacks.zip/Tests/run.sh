#!/bin/bash
gcc -Wall -s functionsMips.c main.c traspuesta.S -std=c99 -o tp1 
## Algunos codigos a tener en cuenta: 139(Segmentation fault), 255(Archivo inexistente)
######TEST 1###########
./tp1 -i wrongfile.txt 2> stderr.txt
if [ "$?" != 255 ] && [ ! -s stderr.txt ]; then ## Si stderr esta vacio la salida no fue dirigida correctamente, si el codigo es 255 no existe el file
   echo "Test archivo inexistente: ERROR";
else
   echo "Test archivo inexistente: OK";
fi
###FIN TEST 1##########


######TEST 2###########
./tp1 -i matrix1 >stdout.txt
DIFF=$(diff expected_result_matrix1.txt stdout.txt) 
if [ "$DIFF" != "" ]; then
   echo "Test output por stdout matrix1: ERROR";
else
   echo "Test output por stdout matrix1: OK";
fi
###FIN TEST 2##########


####TEST 3#######
./tp1 -i matrix1 -o dest_test.txt
DIFF=$(diff expected_result_matrix1.txt dest_test.txt) 
if [ "$DIFF" != "" ]; then
   echo "Test output por file matrix1: ERROR";
else
   echo "Test output por file matrix1: OK";
fi

####FIN TEST 3###


####TEST 4#######
./tp1 -i matrix2 1>stdout.txt 2>stderr.txt #redirijo stdout a stdout.txt y stderr a stderr.txt (2 = file descriptor de stderr)
if [ ! -s stderr.txt ] || [ -s stdout.txt ]; then #La matriz tiene un problema, asique deberia haber contenido en stderr y nada en stdout
   echo "Test matrix2: ERROR";
else
   echo "Test matrix2: OK";
fi
####FIN TEST 4###



####TEST 5#######
./tp1 -i matrix3 -o dest_test.txt 2>stderr.txt 
if [ ! -s stderr.txt ] || [ -s dest_test.txt ]; then
   echo "Test matrix3: ERROR";
else
   echo "Test matrix3: OK";
fi
####FIN TEST 5###



####TEST 6#######
./tp1 -i matrix4 -o dest_test.txt
DIFF=$(diff expected_result_matrix4.txt dest_test.txt) 
if [ "$DIFF" != "" ]; then
   echo "Test output por file matrix4: ERROR";
else
   echo "Test output por file matrix4: OK";
fi

####FIN TEST 6###



####TEST 7#######
./tp1 -i vacio.txt 1>stdout.txt 2>stderr.txt 
if [ ! -s stderr.txt ] || [ -s stdout.txt ]; then
   echo "Test archivo vacio: ERROR";
else
   echo "Test archivo vacio: OK";
fi
####FIN TEST 7###


####TEST 9#######
./tp1 -i unico_elemento.txt -o dest_test.txt
DIFF=$(diff expected_result_test9.txt dest_test.txt) 
if [ "$DIFF" != "" ]; then
   echo "Test matriz de un unico elemento: ERROR";
else
   echo "Test matriz de un unico elemento: OK";
fi

####FIN TEST 9###


####TEST 10#######
./tp1 -i simetrica.txt -o dest_test.txt
DIFF=$(diff expected_result_test10.txt dest_test.txt) 
if [ "$DIFF" != "" ]; then
   echo "Test matriz simetrica: ERROR";
else
   echo "Test matriz simetrica: OK";
fi

####FIN TEST 10###



####TEST 11#######
./tp1 -i test11.txt -o dest_test.txt
DIFF=$(diff expected_result_test11.txt dest_test.txt) 
if [ "$DIFF" != "" ]; then
   echo "Test matriz mas columnas que filas: ERROR";
else
   echo "Test matriz mas columnas que filas: OK";
fi

####FIN TEST 11###


####TEST 12#######
./tp1 -i test12.txt -o dest_test.txt
DIFF=$(diff expected_result_test12.txt dest_test.txt) 
if [ "$DIFF" != "" ]; then
   echo "Test matriz mas filas que columnas: ERROR";
else
   echo "Test matriz mas filas que columnas: OK";
fi

####FIN TEST 12###


####TEST 13#######
./tp1 -i test13.txt -o dest_test.txt
DIFF=$(diff expected_result_test13.txt dest_test.txt) 
if [ "$DIFF" != "" ]; then
   echo "Test matriz 20x20: ERROR";
else
   echo "Test matriz 20x20: OK";
fi
####FIN TEST 13###
